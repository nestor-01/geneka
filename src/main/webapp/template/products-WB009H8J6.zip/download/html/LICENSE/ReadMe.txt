

All Licence Files (GPL-LICENSE.txt and MIT-LICENSE.txt) related to the following scripts:


- Bootstrap
- Magnific Popup
- Particleground
- Stellar
- Owl Carousel
- Scrollit
- Swiper
- WOW